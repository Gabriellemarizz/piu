import { useState } from "react";


const imagens = [
    { src: "/gato1.jpg", descricao: "gato 1" },
    { src: "/gato2.jpg", descricao: "gato 2" },
    { src: "/gato3.jpg", descricao: "gato 3" },
    { src: "/gato4.jpg", descricao: "gato 4" },
    { src: "/gato4.jpg", descricao: "gato 5" },
    { src: "/gato4.jpg", descricao: "gato 6" }
];


function Galeria() {
    const [imagemSelecionada, setImagemSelecionada] = useState(null);


    return (
        <div style={{ textAlign: "center" }}>
            <h1>Gatinhos</h1>
            <div style={{ display: "flex", gap: "20px", justifyContent: "center" }}>
                {imagens.map((item, index) => (
                    <img
                        key={index}
                        src={item.src}
                        alt={item.descricao}
                        style={{ cursor: "pointer", width: "100px", height: "80px", objectFit: "cover" }}
                        onClick={() => setImagemSelecionada(item)}
                    />
                ))}
            </div>


            {imagemSelecionada && (
                <div style={{ marginTop: "40px" }}>
                    <img
                        src={imagemSelecionada.src}
                        alt={imagemSelecionada.descricao}
                        style={{ width: "250px", height: "auto", objectFit: "cover" }}
                    />
                    <p style={{ fontSize: "20px", marginTop: "10px" }}>{imagemSelecionada.descricao}</p>
                </div>
            )}
        </div>
    );
}

export default Galeria;
