import { useState } from "react";
import imagens from Galeria.jsx;

function Descricao() {

    }

    return (

    );
}

export default Descricao;